"""
example.py
-----------
Demonstration of the BioPal package:
Performs Open Reading Frame (ORF) analysis on a DNA sequence.
"""

from biopal.orf_analysis import open_reading_frames


def main():
    seq = input("Enter Sequence:")  # Example DNA sequence
    print("=" * 70)
    print("🔬 BioPal ORF Analysis Example")
    print("=" * 70)
    print(f"Input DNA Sequence: {seq}\n")

    frames = open_reading_frames(seq)

    if not frames:
        print("❌ No valid open reading frames found.")
    else:
        for i, f in enumerate(frames, 1):
            print(f"\n🧬 Candidate Frame {i}")
            print(f"Strand Type : {f['strand']}")
            print(f"RNA Sequence: {f['rna']}")
            print(f"Protein Seq : {f['protein']}")
            print("-" * 70)


if __name__ == "__main__":
    main()
