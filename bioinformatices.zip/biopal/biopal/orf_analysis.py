"""
orf_analysis.py
----------------
This module provides functions for identifying open reading frames (ORFs)
in a DNA sequence and translating them into protein sequences.
"""

from .dna_utils import dna_reverse_complement, generate_frames, split_into_codons
from .transcription_translation import transcribe_dna, translate_dna
from .constants import DNA_START_CODON, DNA_STOP_CODONS


def open_reading_frames(dna_seq: str) -> list[dict]:
    """
    Identify candidate ORFs in both strands of a DNA sequence.

    Parameters
    ----------
    dna_seq : str
        DNA sequence.

    Returns
    -------
    list[dict]
        Each dictionary includes:
        - frame: DNA reading frame sequence
        - strand: 'coding' or 'template'
        - rna: transcribed RNA sequence
        - protein: translated amino acid sequence
    """
    results = []
    dna_rev_comp = dna_reverse_complement(dna_seq)
    frames = generate_frames(dna_seq) + generate_frames(dna_rev_comp)

    for i, frame in enumerate(frames):
        codons = split_into_codons(frame)
        if DNA_START_CODON in codons and any(stop in codons for stop in DNA_STOP_CODONS):
            strand = "coding" if i < 3 else "template"
            rna = transcribe_dna(frame, strand)
            protein = translate_dna(rna)
            results.append({
                "frame": frame,
                "strand": strand,
                "rna": rna,
                "protein": protein
            })
    return results


# Additional ORF analysis functions can be added here as needed...
if __name__ == "__main__":
    sample_dna = "ATGCGTACGTAGCTAGCTAGCTAGCTAA"
    orfs = open_reading_frames(sample_dna)
    for orf in orfs:
        print(f"Strand: {orf['strand']}")
        print(f"Frame: {orf['frame']}")
        print(f"RNA: {orf['rna']}")
        print(f"Protein: {orf['protein']}\n")