"""
transcription_translation.py
-----------------------------
This module provides functions to:
1. Transcribe DNA into RNA
2. Translate RNA into protein sequences
"""

from .constants import RNA_CODON_TABLE_FULL


def transcribe_dna(seq: str, strand_type: str = "coding") -> str:
    """
    Transcribe a DNA strand into RNA.

    Parameters
    ----------
    seq : str
        DNA sequence.
    strand_type : str
        Either "coding" or "template".

    Returns
    -------
    str
        Transcribed RNA sequence.
    """
    seq = seq.upper()

    if strand_type == "coding":
        # Direct transcription: replace Thymine (T) with Uracil (U)
        return seq.replace("T", "U")

    elif strand_type == "template":
        # Complementary transcription based on base-pairing rules
        complement = {"A": "U", "T": "A", "C": "G", "G": "C"}
        return ''.join(complement.get(base, base) for base in seq)

    else:
        raise ValueError("strand_type must be 'coding' or 'template'")


def translate_dna(rna_seq: str) -> str:
    """
    Translate an RNA sequence into a protein sequence.

    Parameters
    ----------
    rna_seq : str
        RNA sequence.

    Returns
    -------
    str
        Amino acid sequence (full names from RNA_CODON_TABLE_FULL).
    """
    codons = [rna_seq[i:i+3] for i in range(0, len(rna_seq), 3)]
    return '-'.join(RNA_CODON_TABLE_FULL.get(c, "X") for c in codons if len(c) == 3)


# Example usage (for testing)
if __name__ == "__main__":
    dna = "ATGGCCATTGTAATGGGCCGCTGAAAGGGTGCCCGATAG"
    rna = transcribe_dna(dna, "coding")
    print("RNA:", rna)
    print("Protein:", translate_dna(rna))
