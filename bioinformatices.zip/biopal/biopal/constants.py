# Constants for BioPal

VALID_DNA_NUCLEOTIDES = {"A", "T", "C", "G"}

VALID_RNA_NUCLEOTIDES = {"A", "U", "C", "G"}

DNA_START_CODON = "ATG"

DNA_STOP_CODONS = {"TAA", "TAG", "TGA"}

RNA_START_CODON = "AUG"

RNA_STOP_CODONS = {"UAA", "UAG", "UGA"}

# Simplified RNA codon table
RNA_CODON_TABLE = {
    "AUG": "M", "UUU": "F", "UUC": "F",
    "UUA": "L", "UUG": "L", "CUU": "L", "CUC": "L",
    "CUA": "L", "CUG": "L", "UCU": "S", "UCC": "S",
    "UCA": "S", "UCG": "S", "UAU": "Y", "UAC": "Y",
    "UGA": "*", "UAG": "*", "UAA": "*"
}

RNA_CODON_TABLE_FULL = {
    'UUU': 'Phenylalanine', 'UUC': 'Phenylalanine', 'UUA': 'Leucine', 'UUG': 'Leucine',
    'CUU': 'Leucine', 'CUC': 'Leucine', 'CUA': 'Leucine', 'CUG': 'Leucine',
    'AUU': 'Isoleucine', 'AUC': 'Isoleucine', 'AUA': 'Isoleucine', 'AUG': 'Methionine',
    'GUU': 'Valine', 'GUC': 'Valine', 'GUA': 'Valine', 'GUG': 'Valine',

    'UCU': 'Serine', 'UCC': 'Serine', 'UCA': 'Serine', 'UCG': 'Serine',
    'CCU': 'Proline', 'CCC': 'Proline', 'CCA': 'Proline', 'CCG': 'Proline',
    'ACU': 'Threonine', 'ACC': 'Threonine', 'ACA': 'Threonine', 'ACG': 'Threonine',
    'GCU': 'Alanine', 'GCC': 'Alanine', 'GCA': 'Alanine', 'GCG': 'Alanine',

    'UAU': 'Tyrosine', 'UAC': 'Tyrosine', 'UAA': 'STOP', 'UAG': 'STOP',
    'CAU': 'Histidine', 'CAC': 'Histidine', 'CAA': 'Glutamine', 'CAG': 'Glutamine',
    'AAU': 'Asparagine', 'AAC': 'Asparagine', 'AAA': 'Lysine', 'AAG': 'Lysine',
    'GAU': 'Aspartic Acid', 'GAC': 'Aspartic Acid', 'GAA': 'Glutamic Acid', 'GAG': 'Glutamic Acid',

    'UGU': 'Cysteine', 'UGC': 'Cysteine', 'UGA': 'STOP', 'UGG': 'Tryptophan',
    'CGU': 'Arginine', 'CGC': 'Arginine', 'CGA': 'Arginine', 'CGG': 'Arginine',
    'AGU': 'Serine', 'AGC': 'Serine', 'AGA': 'Arginine', 'AGG': 'Arginine',
    'GGU': 'Glycine', 'GGC': 'Glycine', 'GGA': 'Glycine', 'GGG': 'Glycine',
}


# Nucleotide complements
DNA_COMPLEMENTS = {
    "A": "T",
    "T": "A",
    "C": "G",
    "G": "C"
}

RNA_COMPLEMENTS = {
    "A": "U",
    "U": "A",
    "C": "G",
    "G": "C"
}
