from .constants import VALID_DNA_NUCLEOTIDES, VALID_RNA_NUCLEOTIDES

def validate_dna(seq: str) -> bool:
    """
    Validate whether a sequence contains only valid DNA nucleotides.

    Parameters
    ----------
    seq : str
        DNA sequence.

    Returns
    -------
    bool
        True if valid, False otherwise.
    """
    seq = seq.upper().strip() # Normalize sequence format
    return all(base in VALID_DNA_NUCLEOTIDES for base in seq)

def validate_rna(seq: str) -> bool:
    """
    Validate whether a sequence contains only valid RNA nucleotides.

    Parameters
    ----------
    seq : str
        RNA sequence.

    Returns
    -------
    bool
        True if valid, False otherwise.
    """
    seq = seq.upper().strip() # Normalize sequence format
    return all(base in VALID_RNA_NUCLEOTIDES for base in seq)

# Additional validation functions can be added here as needed...
# For example, validating protein sequences, codon sequences, etc.

if __name__ == "__main__":
    print("This module provides sequence validation functions for DNA and RNA.")
