def dna_complement(strand: str) -> str:
    """
    Return the complementary DNA strand.
    """
    complement = {"A": "T", "T": "A", "G": "C", "C": "G"}
    return ''.join(complement.get(base, base) for base in strand.upper())


def dna_reverse_complement(strand: str) -> str:
    """
    Return the reverse complement of a DNA strand.
    """
    return dna_complement(strand)[::-1]


def split_into_codons(seq: str) -> list[str]:
    """
    Split a DNA sequence into codons (triplets of nucleotides).
    """
    return [seq[i:i+3] for i in range(0, len(seq), 3)]


def generate_frames(seq: str) -> list[str]:
    """
    Generate the three possible reading frames for a given DNA strand.
    """
    return [seq[i:] for i in range(3)]

def count_nucleotides(seq: str) -> dict[str, int]:
    """
    Count the occurrences of each nucleotide in a DNA sequence.

    Parameters
    ----------
    seq : str
        DNA sequence.

    Returns
    -------
    dict[str, int]
        A dictionary with nucleotides as keys and their counts as values.
    """
    seq = seq.upper().strip()  # Normalize sequence format
    counts = {"A": 0, "T": 0, "C": 0, "G": 0}
    for base in seq:
        if base in counts:
            counts[base] += 1
    return counts

# Additional DNA utility functions can be added here as needed...
if __name__ == "__main__":
    seq = "ATGCGTACGTA"
    print("Original:", seq)
    print("Complement:", dna_complement(seq))
    print("Reverse Complement:", dna_reverse_complement(seq))
    print("Frames:", generate_frames(seq))
    print("Codons:", split_into_codons(seq))
    print("Counts:", count_nucleotides(seq))