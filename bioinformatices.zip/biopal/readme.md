# 🧬 BioPal — A Friendly Bioinformatics Companion

**BioPal** is a Python toolkit for DNA manipulation, transcription/translation, and open reading frame (ORF) detection.

---

## 🚀 Features
- DNA complement & reverse complement
- Reading frame generation
- Transcription (DNA → RNA)
- Translation (RNA → Protein)
- ORF detection (both strands)

---

## 📦 Installation

```bash
pip install -e .
