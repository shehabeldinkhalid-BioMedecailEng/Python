from biopal.constants import (
    VALID_DNA_NUCLEOTIDES, VALID_RNA_NUCLEOTIDES,
    DNA_START_CODON, DNA_STOP_CODONS,
    RNA_START_CODON, RNA_STOP_CODONS
)

def test_constants_values():
    assert DNA_START_CODON == "ATG"
    assert RNA_START_CODON == "AUG"
    assert isinstance(DNA_STOP_CODONS, set)
    assert "TAA" in DNA_STOP_CODONS
    assert VALID_DNA_NUCLEOTIDES == {"A", "T", "C", "G"}
    assert VALID_RNA_NUCLEOTIDES == {"A", "U", "C", "G"}
