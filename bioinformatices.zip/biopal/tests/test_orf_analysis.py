from biopal.orf_analysis import open_reading_frames

def test_open_reading_frames():
    dna = "ATGCGTATCAGTAA"
    results = open_reading_frames(dna)
    assert isinstance(results, list)
    assert all(isinstance(r, dict) for r in results)
    for r in results:
        assert "frame" in r
        assert "strand" in r
        assert "rna" in r
        assert "protein" in r
