from biopal.validation import is_valid_dna, is_valid_rna

def test_is_valid_dna():
    assert is_valid_dna("ATGC") is True
    assert is_valid_dna("ATXG") is False

def test_is_valid_rna():
    assert is_valid_rna("AUGC") is True
    assert is_valid_rna("AUTG") is False
