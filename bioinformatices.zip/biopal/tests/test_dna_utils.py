from biopal.dna_utils import (
    dna_complement, dna_reverse_complement,
    split_into_codons, generate_frames, count_nucleotides
)

def test_dna_complement():
    assert dna_complement("ATCG") == "TAGC"

def test_reverse_complement():
    assert dna_reverse_complement("ATCG") == "CGAT"

def test_split_into_codons():
    seq = "ATGCGTATC"
    assert split_into_codons(seq) == ["ATG", "CGT", "ATC"]

def test_generate_frames():
    seq = "ATGCGTATC"
    frames = generate_frames(seq)
    assert len(frames) == 3
    assert frames[0] == seq
    assert frames[1] == seq[1:]
    assert frames[2] == seq[2:]

def test_count_nucleotides():
    seq = "AATTCCGG"
    counts = count_nucleotides(seq)
    assert counts == {"A": 2, "T": 2, "C": 2, "G": 2}
