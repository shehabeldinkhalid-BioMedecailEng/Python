from biopal.transcription_translation import transcribe_dna, translate_dna

def test_transcribe_coding():
    dna = "ATGCGA"
    assert transcribe_dna(dna, "coding") == "AUGCGA"

def test_transcribe_template():
    dna = "ATGCGA"
    assert transcribe_dna(dna, "template") == "UACGCU"

def test_translate_dna():
    rna = "AUGUUUUAA"  # AUG -> Methionine, UUU -> Phenylalanine, UAA -> STOP
    protein = translate_dna(rna)
    assert "Methionine" in protein
