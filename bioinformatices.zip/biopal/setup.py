from setuptools import setup, find_packages

setup(
    name='BioPal',
    version='1.0.0',
    author='Mohamed Mahmoud Abd El Maksoud',
    description='A friendly bioinformatics toolkit for DNA, RNA and ORF analysis.',
    packages=find_packages(),
    python_requires='>=3.8',
    install_requires=[],
    classifiers=[
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
)
